require 'spec_helper.rb'

describe MoviesController do
  describe "GET 'index'" do
    it "should be successful" do
      get 'index'
      response.should be_success
    end
  end

  describe 'find with same director' do
    it 'should find all movies with the same director' do
      movie = mock_model(Movie)
      Movie.stub!(:similar).and_return(movie)
puts Movie.should_receive(:find_by_id).with(1).and_return(movie)
#m.stub(:director).and_returns(nil)
#Movie.should_recieve(:find_by_id).and_return(m)
#      post :similar, {:id => 1}
    end

#it 'should show the home page if no movies with the same director are found' do
#    end
  end
end
