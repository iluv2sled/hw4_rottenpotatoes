require 'spec_helper.rb'

#describe Movie do
#  it "dsfs" do
#end


